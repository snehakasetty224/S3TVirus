/**
 * 
 */
package com.s3t.rest.get.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONArray;
import org.json.JSONObject;
import oauth.signpost.OAuthConsumer;
import oauth.signpost.commonshttp.CommonsHttpOAuthConsumer;
import oauth.signpost.exception.OAuthCommunicationException;
import oauth.signpost.exception.OAuthExpectationFailedException;
import oauth.signpost.exception.OAuthMessageSignerException;

/**
 * @author Sindhu
 *
 */
public class ApacheHttpClientGet {


	public static void main(String[] args) throws JSONException {
		try
		{
			OAuthConsumer consumer = new CommonsHttpOAuthConsumer("nbt87Jdi8QAfBZcqKRmul6Tx8","AntAPekDj3bAeaYmEheXDohnA7Uyvmoa7LkDyF6v4a0v4XhMa3");
			consumer.setTokenWithSecret("779387545645817856-fbTRHnvG44fJ0MsNkF8hOahviVgdcpg", "CHQCY8u6wNMlB8KiOuvencRLmtCelY6FQws7xFYeFCrPe");
           
			// This API gives all the tweets done by user that gets displayed in user timeline page and also it gives tweet count for a user
		    HttpGet getRequest1 = new HttpGet("https://api.twitter.com/1.1/statuses/user_timeline.json");
		    //"https://api.twitter.com/1.1/followers/list.json?cursor=-1&screen_name=Tower_Sssindhup&skip_status=true&include_user_entities=true");
		    getRequest1.addHeader("accept", "application/json");
		    consumer.sign(getRequest1);
		    DefaultHttpClient httpClient1 = new DefaultHttpClient();
		
		    HttpResponse response1 = httpClient1.execute(getRequest1);
		    if (response1.getStatusLine().getStatusCode() != 200) 
		     {
			throw new RuntimeException("Failed : HTTP error code : "+ response1.getStatusLine().getStatusCode());
		     }
		   BufferedReader br1 = new BufferedReader(new InputStreamReader((response1.getEntity().getContent())));
		

		   String output1;
		   System.out.println("\n Unformatted Output from the Server for tweet count and tweets \n");
		   while ((output1 = br1.readLine()) != null) {
			System.out.println(output1);
			
			// To display tweet count and tweets of the user 
		   JSONArray json1= new JSONArray(output1); 
		   int count= json1.length();
		   System.out.println("\n tweet Count=" + count);
		   System.out.println("\n tweets from user timeline\n");
		   int i;
		   for (i=0;i<json1.length();i++)
			{
				JSONObject tweetarray=json1.getJSONObject(i);
				String tweet= tweetarray.getString("text");
				System.out.println("\n" + tweet);
			}
			
			httpClient1.getConnectionManager().shutdown();
		 }	
		
		    // This API gives the following count for a user
		    HttpGet getRequest2 = new HttpGet("https://api.twitter.com/1.1/friends/ids.json");
			getRequest2.addHeader("accept", "application/json");
			consumer.sign(getRequest2);
			DefaultHttpClient httpClient2 = new DefaultHttpClient();
			
			HttpResponse response2 = httpClient2.execute(getRequest2);

			if (response2.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
				   + response2.getStatusLine().getStatusCode());
			}

			BufferedReader br2 = new BufferedReader( new InputStreamReader((response2.getEntity().getContent())));
			String output2;
			System.out.println("\nUnformatted Output from the Server for friends count \n");
			while ((output2 = br2.readLine()) != null) {
			System.out.println(output2);
				
			// ---To Display Following Count---		
			JSONObject json2=new JSONObject(output2);
				
			JSONArray Friendsid= json2.getJSONArray("ids");
			int count= Friendsid.length();
			System.out.println("\n Following Count=" + count);
				
			httpClient2.getConnectionManager().shutdown();
			}
			
		    // This API gives followers count for a user
			HttpGet getRequest3 = new HttpGet("https://api.twitter.com/1.1/followers/ids.json");
			getRequest3.addHeader("accept", "application/json");
			consumer.sign(getRequest3);
			DefaultHttpClient httpClient3 = new DefaultHttpClient();
			
			HttpResponse response3 = httpClient3.execute(getRequest3);

			if (response3.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
				   + response3.getStatusLine().getStatusCode());
			}

			BufferedReader br3 = new BufferedReader( new InputStreamReader((response3.getEntity().getContent())));
			String output3;
			System.out.println("\nUnformatted Output from the Server for followers count  \n");
			while ((output3 = br3.readLine()) != null) {
				System.out.println(output3);
				
			 //---- To Display Follower count-----
			 JSONObject json3=new JSONObject(output3);
					
		     JSONArray Followersid= json3.getJSONArray("ids");
			 int count= Followersid.length();
			  System.out.println("\n Followers Count=" + count);
					
				
				httpClient3.getConnectionManager().shutdown();
			}
			
			// This API gives list of friends names
			HttpGet getRequest4= new HttpGet("https://api.twitter.com/1.1/friends/list.json");
			getRequest4.addHeader("accept", "application/json");
			consumer.sign(getRequest4);
			DefaultHttpClient httpClient4= new DefaultHttpClient();
			
			HttpResponse response4= httpClient4.execute(getRequest4);
			
			if(response4.getStatusLine().getStatusCode()!=200) {
				throw new RuntimeException("Failed: HTTP error code :" 
			     + response4.getStatusLine().getStatusCode());
			}
	
			BufferedReader br4 = new BufferedReader( new InputStreamReader((response4.getEntity().getContent())));
			String output4;
			System.out.println(" Unformatted Output from the Server for List of friends names");
			while((output4=br4.readLine())!= null) {
				 System.out.println(output4);
				 
				 JSONObject json4= new JSONObject(output4);
				 JSONArray friendslist= json4.getJSONArray("users");
				 int i;
				  for (i=0;i<friendslist.length();i++)
					{
						JSONObject friendsname=friendslist.getJSONObject(i);
						String name=friendsname.getString("name");
						System.out.println("\n" + name);
					}
					
			httpClient4.getConnectionManager().shutdown();
				 
			}
			
			// This API gives list of followers names
			HttpGet getRequest5= new HttpGet("https://api.twitter.com/1.1/followers/list.json");
			getRequest5.addHeader("accept", "application/json");
			consumer.sign(getRequest5);
			DefaultHttpClient httpClient5= new DefaultHttpClient();
			
			HttpResponse response5= httpClient5.execute(getRequest5);
			
			if(response5.getStatusLine().getStatusCode()!=200) {
				throw new RuntimeException("Failed: HTTP error code :" 
			     + response5.getStatusLine().getStatusCode());
			}
	
			BufferedReader br5 = new BufferedReader( new InputStreamReader((response5.getEntity().getContent())));
			String output5;
			System.out.println(" Unformatted Output from the Server for List of friends names");
			while((output5=br5.readLine())!= null) {
				 System.out.println(output5);
				 
				 JSONObject json5= new JSONObject(output5);
				 JSONArray followerslist= json5.getJSONArray("users");
				 int i;
				  for (i=0;i<followerslist.length();i++)
					{
						JSONObject followersname=followerslist.getJSONObject(i);
						String fname=followersname.getString("name");
						System.out.println("\n" + fname);
					}
					
			httpClient5.getConnectionManager().shutdown();
				 
			}
			
			//This API gives list of locations that Twitter has trending topic information
			HttpGet getRequest6= new HttpGet("https://api.twitter.com/1.1/trends/available.json");
			getRequest6.addHeader("accept", "application/json");
			consumer.sign(getRequest6);
			DefaultHttpClient httpClient6= new DefaultHttpClient();
			
			HttpResponse response6= httpClient6.execute(getRequest6);
			
			if(response6.getStatusLine().getStatusCode()!=200) {
				throw new RuntimeException("Failed: HTTP error code :" 
			     + response5.getStatusLine().getStatusCode());
			}
	
			BufferedReader br6 = new BufferedReader( new InputStreamReader((response6.getEntity().getContent())));
			String output6;
			System.out.println(" Unformatted Output from the Server for List of friends names");
			while((output6=br6.readLine())!= null) {
				 System.out.println(output6);
				 
				 //JSONObject json6= new JSONObject(output6);
				 JSONArray json6= new JSONArray(output6);
				 int i;
				 System.out.println("\n Locations that Twitter has trending topic information");
				  for (i=0;i<json6.length();i++)
					{
						JSONObject trendslist =json6.getJSONObject(i);
						String trendsplace=trendslist.getString("name");
						String trendscountry=trendslist.getString("country");
						System.out.println("\n" + trendsplace +"," + trendscountry );
					}
					
			httpClient6.getConnectionManager().shutdown();
			}
			
			// This API gives tweets that gets displayed in home timeline page
			HttpGet getRequest7 = new HttpGet("https://api.twitter.com/1.1/statuses/home_timeline.json");
		    getRequest7.addHeader("accept", "application/json");
		    consumer.sign(getRequest7);
		    DefaultHttpClient httpClient7 = new DefaultHttpClient();
		
		    HttpResponse response7 = httpClient7.execute(getRequest7);
		    if (response7.getStatusLine().getStatusCode() != 200) 
		     {
			throw new RuntimeException("Failed : HTTP error code : "+ response7.getStatusLine().getStatusCode());
		     }
		   BufferedReader br7 = new BufferedReader(new InputStreamReader((response7.getEntity().getContent())));
		

		   String output7;
		   System.out.println("\n Unformatted Output from the Server for tweet count and tweets \n");
		   while ((output7 = br7.readLine()) != null) {
			System.out.println(output7);
			
			// To display tweet count and tweets of the user 
		   JSONArray json7= new JSONArray(output7); 
		   System.out.println("\n Tweets displayed in home timeline page\n");
			
		   int i;
		   for (i=0;i<json7.length();i++)
			{
				JSONObject alltweetarray=json7.getJSONObject(i);
				String alltweet= alltweetarray.getString("text");
				System.out.println("\n" + alltweet);
			}
			
			httpClient7.getConnectionManager().shutdown();
		 }	
		
			
	  }catch (ClientProtocolException e) {

		e.printStackTrace();

	  } catch (IOException e) {
		  
		e.printStackTrace();
	  } catch (OAuthMessageSignerException e) {	
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (OAuthExpectationFailedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (OAuthCommunicationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	
}
