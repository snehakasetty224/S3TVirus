/**
 * 
 */
package com.s3t.rest.get.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONArray;
import org.json.JSONObject;
import oauth.signpost.OAuthConsumer;
import oauth.signpost.commonshttp.CommonsHttpOAuthConsumer;
import oauth.signpost.exception.OAuthCommunicationException;
import oauth.signpost.exception.OAuthExpectationFailedException;
import oauth.signpost.exception.OAuthMessageSignerException;

/**
 * @author Sindhu
 *
 */
public class ApacheHttpClientGet {


	public static void main(String[] args) throws JSONException {
		try
		{
		OAuthConsumer consumer = new CommonsHttpOAuthConsumer("","");
		consumer.setTokenWithSecret("", "");
		
		HttpGet getRequest = new HttpGet(
				"https://api.twitter.com/1.1/statuses/user_timeline.json");
				//"https://api.twitter.com/1.1/friends/ids.json");
				//"https://api.twitter.com/1.1/followers/ids.json");
				//"https://api.twitter.com/1.1/statuses/home_timeline.json");
		//"https://api.twitter.com/1.1/followers/list.json?cursor=-1&screen_name=Tower_Sssindhup&skip_status=true&include_user_entities=true");
		getRequest.addHeader("accept", "application/json");
		consumer.sign(getRequest);
		DefaultHttpClient httpClient = new DefaultHttpClient();
		
		

		HttpResponse response = httpClient.execute(getRequest);

		if (response.getStatusLine().getStatusCode() != 200) {
			throw new RuntimeException("Failed : HTTP error code : "
			   + response.getStatusLine().getStatusCode());
		}

		BufferedReader br = new BufferedReader(
                         new InputStreamReader((response.getEntity().getContent())));
		

		String output;
		System.out.println("Unformatted Output from the Server \n");
		while ((output = br.readLine()) != null) {
			System.out.println(output);
			
			
		// ---To Display Following Count---		
		/*JSONObject json=new JSONObject(output);
		
		JSONArray Friendsid= json.getJSONArray("ids");
		int count= Friendsid.length();
		System.out.println("Friends Count=" + count);*/
		
			
		//---- To Display Follower count-----
      /* JSONObject json=new JSONObject(output);
		
		JSONArray Followersid= json.getJSONArray("ids");
		int count= Followersid.length();
		System.out.println("Followers Count=" + count);
		*/
		// ----To display tweet count and tweets of the user 
		JSONArray json= new JSONArray(output); 
		int count= json.length();
		System.out.println("tweet Count=" + count);
		
		int i;
		for (i=0;i<json.length();i++)
		{
			JSONObject tweetarray=json.getJSONObject(i);
			String tweet= tweetarray.getString("text");
			System.out.println("\n" + tweet);
		}
		
		httpClient.getConnectionManager().shutdown();
		}
			
	  }catch (ClientProtocolException e) {

		e.printStackTrace();

	  } catch (IOException e) {
		  
		e.printStackTrace();
	  } catch (OAuthMessageSignerException e) {	
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (OAuthExpectationFailedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (OAuthCommunicationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	
}
